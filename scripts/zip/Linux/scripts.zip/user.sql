create database magento;
GRANT ALL ON magento.* TO 'magento'@'IP-NETMASK-REPLACEME' IDENTIFIED BY 'magento';
GRANT ALL ON magento.* TO 'magento'@'IP-NETMASK-REPLACEME' IDENTIFIED BY 'magento';
